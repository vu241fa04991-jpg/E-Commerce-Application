from django.db import models


# Create your models here.
class ProductModel(models.Model):
    id = models.AutoField(primary_key=True)
    p_name = models.CharField(max_length=200)
    p_type = models.CharField(max_length=200)
    p_price = models.CharField(max_length=200)
    p_quantity = models.CharField(max_length=200)

class Cart(models.Model):
    cart_id = models.AutoField(primary_key=True)
    product_id=models.IntegerField()
    p_price=models.FloatField()
class CartItem(models.Model):
    product_name = models.CharField(max_length=200)
    quantity = models.IntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

class CartModel(models.Model):
    product_name = models.CharField(max_length=100)
    added_on = models.DateTimeField(auto_now_add=True)
