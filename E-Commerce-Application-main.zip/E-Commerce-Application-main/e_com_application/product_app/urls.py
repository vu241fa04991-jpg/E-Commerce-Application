from django.urls import path
from . import views

urlpatterns = [
    path('viewproducts/', views.view_all_products, name='view_all_products'),
    path('addproduct/', views.add_product, name='add_product'),
    path('delete/<int:id>/', views.del_by_id, name='del_by_id'),
    path('cart-success/<str:name>/', views.cart_success, name='cart_success'),
    path('delete-cart/<int:id>/', views.delete_cart_item, name='delete_cart_item'),
]

#http://127.0.0.1:8000/products/viewproducts/
