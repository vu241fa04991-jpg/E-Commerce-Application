from django.shortcuts import render, redirect
from .models import ProductModel, CartModel


# Yeh function missing tha, isliye AttributeError aa raha hai
def add_product(request):
    if request.method == 'POST':
        ProductModel.objects.create(
            p_name=request.POST.get('p_name'),
            p_type=request.POST.get('p_type'),
            p_price=request.POST.get('p_price'),
            p_quantity=request.POST.get('p_quantity')
        )
        return redirect('view_all_products')
    return render(request, "add_product.html")


def view_all_products(request):
    data = ProductModel.objects.all()
    return render(request, "productlists.html", {'data': data})


def cart_success(request, name):
    if name != "MyCart":
        CartModel.objects.create(product_name=name)

    items = CartModel.objects.all().order_by('-added_on')
    return render(request, "success.html", {
        'product_name': name if name != "MyCart" else "Your Shopping Cart",
        'cart_items': items
    })


def delete_cart_item(request, id):
    # filter use karne se crash nahi hoga agar item na mile
    CartModel.objects.filter(id=id).delete()
    return redirect('cart_success', name='MyCart')


def del_by_id(request, id):
    ProductModel.objects.filter(id=id).delete()
    return redirect('view_all_products')