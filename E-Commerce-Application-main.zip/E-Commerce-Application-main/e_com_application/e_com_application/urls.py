from django.contrib import admin
from django.urls import path,include


urlpatterns = [
    path('admin/', admin.site.urls),
    path('products/', include('product_app.urls')) # Yahan 's' add kar diya
]

