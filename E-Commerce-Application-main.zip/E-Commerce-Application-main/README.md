# E-Commerce-Application
NeoCart – A Full-Stack Django E-Commerce Application:   NeoCart is a robust and scalable e-commerce platform built using the Django framework. The application features a clean, modern Bootstrap 5 interface that allows users to browse collections, manage product stock, and handle a real-time shopping cart system.
